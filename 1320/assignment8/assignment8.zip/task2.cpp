#include <iostream>
#include <cstdlib>
using namespace std;

int main(){

    bool player, RollorHold = 1;
    int die, turnTotal = 0;
    srand(time(NULL));

    cout << "Is the player a human(1) or a computer(0)? ";
    cin >> player; 

    if (player == 1){
        while (RollorHold == 1){
            cout << "1 to roll, 0 to hold ";
            cin >> RollorHold;
            if (RollorHold == 1){
                die = rand()%6 +1;
                if (die != 3){
                    cout << "Player rolled " << die << endl;
                    turnTotal = turnTotal + die;
                    cout << "The current turn total is " << turnTotal << endl;
                }

                if (die == 3){
                    
                    cout << "PLayer rolled " << die << endl;               
                    turnTotal = 3;
                    cout << "The current turn total is " << turnTotal << endl;
                }
            }        

        }
        cout << "Final turn total is " << turnTotal << endl;

    }

    int minTurns = 5, i;
    if (player == 0){
        for (i = 0; i < minTurns; i++){
            cout << "1 to roll, 0 to hold" << endl;
            cout << "The computer chose to roll" << endl;
            die = rand()%6 +1;
            cout << "The player rolled " << die << endl;
            turnTotal = turnTotal + die;
            cout << "The current turn total is " << turnTotal << endl;

        }

        while (RollorHold == 1){
            cout << "1 to roll, 0 to hold" << endl;
            RollorHold = rand()%2;
            if (RollorHold == 1){
                cout << "The computer chose to roll" << endl;
                die = rand()%6 + 1;
                cout << "The player rolled " << die << endl;
                turnTotal = turnTotal + die;
                cout << "The current turn total is " << turnTotal << endl;
             }
            
            if (RollorHold == 0){
                cout << "The computer chose to hold" << endl;
                cout << "The final turn total is " << turnTotal << endl;
                break;
            }

        }



    }
    return 0;
}