#include <iostream>
using namespace std;

int main(){
    float weight, MET, caloriesUsed;
    int mins;
   

    cout << "Weight(lb): ";
    cin >> weight;

    cout << "METS value: ";
    cin >> MET;

    cout << "Time in minutes: ";
    cin >> mins;

    const float KGweight = weight / 2.2;

    caloriesUsed = 0.0175 * MET * KGweight * mins;
    cout << "Calories Burned:" << endl << caloriesUsed << endl;
    
    return 0;

}