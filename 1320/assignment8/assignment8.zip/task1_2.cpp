#include <iostream>
#include <iomanip>
using namespace std;


int main(){
    
    int n ,i;
    float g, r;
    cout << "The square root of" << endl;
    cin >> n;

    cout << "Enter guess:" << endl;
    cin >> g;


 for (i = 0; i < 5; i++){
        
    r = n / (float)g;
    g = (float)((float)g + r) / 2;
 }

    cout << "The square root of " << n << "is" << setprecision(2) << fixed << g << endl;
    
    return 0;
}
    
