#include <iostream>
using namespace std;

int main (){

    int timeSeconds, timeMinutes, timeHours, secondsRemaining, minutesRemaining;
    cout << "Input the time in seconds: " << endl;
    cin >> timeSeconds;


    secondsRemaining = timeSeconds % 60 ;
    timeMinutes = timeSeconds / 60;
    
    minutesRemaining = timeMinutes % 60;
    timeHours = timeMinutes / 60;

    cout << timeHours << "hours" << minutesRemaining << "minutes" << secondsRemaining << "seconds" << endl;

    return 0;
}