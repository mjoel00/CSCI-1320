// cicleAreaBuggy.cpp
// Program to calculate the area of a circle
// User is promted for the radius

#include <iostream>
using namespace std;

int main()
{
	const double pi = 3.14;
	double radius = 4; // "const" omitted because the variable radius is not constant

	cout << "Please enter radius: ";
	cin >> radius;

	double area;
	area = pi * radius * radius; // did not declare the variable area

	cout << "The area of a circle with radius " << radius  <<
	  " is " << area << "." << endl;


    return 0;
}

